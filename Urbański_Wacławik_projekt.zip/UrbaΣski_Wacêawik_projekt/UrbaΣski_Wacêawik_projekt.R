# Biblioteki
library(readxl)
library(e1071)
library(tseries)
library(forecast)
library(corrplot)
library(tidyr)
library(dplyr)
library(ggplot2)
library(rstatix)
library(nortest)
library(lmtest)
library(stats)
library(trend)
library(Kendall)
library(mbstats)
library(aod)

# Wczytanie danych
dane <- read_excel("dane_lab.xlsx")

# 1. Analiza podstawowych statystyk
summary(dane)

sapply(dane, function(x)
{
  if(is.numeric(x))
  {
    c(
      srednia = mean(x),
      odchylenie = sd(x),
      kurtoza = kurtosis(x),
      skosnosc = skewness(x),
      wsp.zmienn = sd(x)/mean(x)
    )
  }
  else { NA}
}
)

# Analiza współczynników korelacji pomiędzy zmiennymi
korelacja<-cor(dane, use="complete.obs", method = "pearson")
par(mar = c(1, 1, 5, 1))

corrplot(korelacja, method = "color",
         addCoef.col = "black",
         number.cex = 0.7,
         tl.col = "black",
         tl.cex = 0.8,
         tl.srt = 45,
         col = colorRampPalette(c("blue", "white", "red"))(200))


dane <- subset(dane, select = -c(x3, x5, x7, x8))

# Wykresy zależności pomiędzy zmiennymi.
etykieta_y <- "Przeciętne kwartalne wynagrodzenie brutto w sektorze przedsiębiorstw"

# Wykres dla x1
ggplot(dane, aes(x = x1, y = y)) +
  geom_point(color = "royalblue", size = 2.6) +
  labs(
    title = "Zależność wynagrodzenia od liczby pracujących",
    x = "Liczba pracujących w sektorze przedsiębiorstw",
    y = etykieta_y
  ) +
  theme_classic()

# Wykres dla x2
ggplot(dane, aes(x = x2, y = y)) +
  geom_point(color = "royalblue", size = 2.6) +
  labs(
    title = "Zależność wynagrodzenia od liczby bezrobotnych",
    x = "Liczba zarejestrowanych bezrobotnych (w tysiącach)",
    y = etykieta_y
  ) +
  theme_classic()

# Wykres dla x4
ggplot(dane, aes(x = x4, y = y)) +
  geom_point(color = "royalblue", size = 2.6) +
  labs(
    title = "Zależność wynagrodzenia od wysokości świadczeń społecznych",
    x = "Wysokość świadczeń społecznych (w milionach)",
    y = etykieta_y
  ) +
  theme_classic()

# Wykres dla x6
ggplot(dane, aes(x = x6, y = y)) +
  geom_point(color = "royalblue", size = 2.6) +
  labs(
    title = "Zależność wynagrodzenia od wysokości wskaźnika cen",
    x = "Wskaźnik cen towarów i usług konsumpcyjnych (inflacja)",
    y = etykieta_y
  ) +
  theme_classic()

# Wykres dla x9
ggplot(dane, aes(x = x9, y = y)) +
  geom_point(color = "royalblue", size = 2.6) +
  labs(
    title = "Zależność wynagrodzenia od wysokości nakładów inwestycyjnych",
    x = "Nakłady inwestycyjne (w milionach)",
    y = etykieta_y
  ) +
  theme_classic()

# Wykres dla x10
ggplot(dane, aes(x = x10, y = y)) +
  geom_point(color = "royalblue", size = 2.6) +
  labs(
    title = "Zależność wynagrodzenia od aktywów obrotowych",
    x = "Aktywa obrotowe przedsiębiorstw (w milionach)",
    y = etykieta_y
  ) +
  theme_classic()

# 2. Odpowiednie przygotowanie danych
# Badanie stacjonarności zmiennych i eliminacja niestacjonarności

adf.test(dane$y)
kpss.test(dane$y)

adf.test(dane$x1)
kpss.test(dane$x1)

adf.test(dane$x2)
kpss.test(dane$x2)

adf.test(dane$x4)
kpss.test(dane$x4)

adf.test(dane$x6)
kpss.test(dane$x6)

adf.test(dane$x9)
kpss.test(dane$x9)

adf.test(dane$x10)
kpss.test(dane$x10)

ndiffs(dane$y)
ndiffs(dane$x1)
ndiffs(dane$x2)
ndiffs(dane$x4)
ndiffs(dane$x6)
ndiffs(dane$x9)
ndiffs(dane$x10)

dane$y <- c ( NA , diff (dane$y) )

dane$y <- c ( NA , diff (dane$y) )

dane$x1 <- c ( NA , diff (dane$x1) )

dane$x2 <- c ( NA , diff (dane$x2) )

dane$x4 <- c ( NA , diff (dane$x4) )

dane$x4 <- c ( NA , diff (dane$x4) )

dane$x6 <- c ( NA , diff (dane$x6) )

dane$x6 <- c ( NA , diff (dane$x6) )

dane$x9 <- c ( NA , diff (dane$x9) )

dane$x10 <- c ( NA , diff (dane$x10) )

dane <- dane[-c(1, 2), ]

adf.test(dane$y)
kpss.test(dane$y)

adf.test(dane$x1)
kpss.test(dane$x1)

adf.test(dane$x2)
kpss.test(dane$x2)

adf.test(dane$x4)
kpss.test(dane$x4)

adf.test(dane$x6)
kpss.test(dane$x6)

adf.test(dane$x9)
kpss.test(dane$x9)

adf.test(dane$x10)
kpss.test(dane$x10)

# Eliminacja wartości odstających.
par(mfrow = c(1, 1))
box_col <- "royalblue"

# Wykresy
boxplot(dane$y,
        col = box_col,
        main = "Rozkład zmiennej y",
        ylab = "Wartości y")

boxplot(dane$x1,
        col = box_col,
        main = "Liczba pracujących (x1)",
        ylab = "Liczba pracujących")

boxplot(dane$x2,
        col = box_col,
        main = "Liczba bezrobotnych (x2)",
        ylab = "Bezrobotni [tys.]")

boxplot(dane$x4,
        col = box_col,
        main = "Świadczenia społeczne (x4)",
        ylab = "Świadczenia [mln]")

boxplot(dane$x6,
        col = box_col,
        main = "Inflacja (x6)",
        ylab = "Wskaźnik cen")

boxplot(dane$x9,
        col = box_col,
        main = "Nakłady inwestycyjne (x9)",
        ylab = "Nakłady [mln]")

boxplot(dane$x10,
        col = box_col,
        main = "Aktywa obrotowe (x10)",
        ylab = "Aktywa [mln]")

ramka<-  data.frame(
  y = dane$y,
  x1 = dane$x1,
  x2 = dane$x2,
  x4 =dane$x4,
  x6 = dane$x6,
  x9 = dane$x9,
  x10 = dane$x10
)

replace_outliers_with_quartiles <- function(column) {
  Q1 <- quantile(column, 0.25, na.rm = TRUE)
  Q3 <- quantile(column, 0.75, na.rm = TRUE)
  IQR_val <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_val
  upper <- Q3 + 1.5 * IQR_val
  
  column[column < lower] <- Q1
  column[column > upper] <- Q3
  
  return(column)
}

dane_clean <- as.data.frame(lapply(ramka, replace_outliers_with_quartiles))

par(mfrow = c(3, 3))
box_col <- "red"

# Wykresy
boxplot(dane_clean$y,
        col = box_col,
        main = "Rozkład zmiennej y",
        ylab = "Wartości y")

boxplot(dane_clean$x1,
        col = box_col,
        main = "Liczba pracujących (x1)",
        ylab = "Liczba pracujących")

boxplot(dane_clean$x2,
        col = box_col,
        main = "Liczba bezrobotnych (x2)",
        ylab = "Bezrobotni [tys.]")

boxplot(dane_clean$x4,
        col = box_col,
        main = "Świadczenia społeczne (x4)",
        ylab = "Świadczenia [mln]")

boxplot(dane_clean$x6,
        col = box_col,
        main = "Inflacja (x6)",
        ylab = "Wskaźnik cen")

boxplot(dane_clean$x9,
        col = box_col,
        main = "Nakłady inwestycyjne (x9)",
        ylab = "Nakłady [mln]")

boxplot(dane_clean$x10,
        col = box_col,
        main = "Aktywa obrotowe (x10)",
        ylab = "Aktywa [mln]")

# 3. Zastosowanie wybranej metody doboru zmiennych do modelu - metoda krokowa wsteczna
dane_ucz <- dane_clean[1:43, ]
dane_test <- dane_clean[44:58, ]

model1<-lm(y ~ x1 + x2 + x4 + x6 + x9 + x10, data = dane_ucz)
summary(model1)

model2<-lm(y ~ x1 + x2 + x6 + x9 + x10, data = dane_ucz)
summary(model2)

model3<-lm(y ~ x1 + x2 + x9 + x10, data = dane_ucz)
summary(model3)

# 4. Budowa modelu
model<-lm(y ~ x1 + x2 + x9 + x10, data = dane_ucz)
summary(model)


# 5. Weryfikacja poprawności modelu
# Badanie normalności rozkładu reszt.
reszty<-model$residuals

qqnorm(reszty, main = "Wykres reszt modelu",
       xlab = "Teoretyczne kwantyle",
       ylab = "Reszty modelu")
qqline(reszty, col = "red")

shapiro.test(reszty)
lillie.test(reszty)
ad.test(reszty)

# Testowanie autokorelacji 
pacf(reszty, main="PACF", xlab="lag", ylab="Partial ACF")
acf(reszty, main="ACF", xlab="lag", ylab="ACF")

bgtest(model,order=1)
bgtest(model,order=2)
bgtest(model,order=3)
bgtest(model,order=4)
bgtest(model,order=5)
bgtest(model,order=6)
bgtest(model,order=7)
bgtest(model,order=8)
bgtest(model,order=10)

# Badanie heteroskedastyczności
bptest(model)

white_test <- bptest(model, ~ fitted(model) + I(fitted(model)^2))
print(white_test)

model_logx <- lm(y ~ x1 + x2 + log(x9) + x10, data = dane_ucz)
summary(model_logx)

white_test1 <- bptest(model_logx, ~ fitted(model_logx) + I(fitted(model_logx)^2))
print(white_test1)
bptest(model_logx)

model_logx <- lm(y ~ x1 + x2 + log(x9) , data = dane_ucz)
summary(model_logx)

white_test1 <- bptest(model_logx, ~ fitted(model_logx) + I(fitted(model_logx)^2))
print(white_test1)
bptest(model_logx)

# Testowanie współliniowości (VIF)
car::vif(model_logx)

# Testowanie stabilności parametrów modelu (test Chowa).
dane_low <- dane_ucz[1:21,]
dane_high <- dane_ucz[22:43,]

model_low <- lm(y ~ x1 + x2 + log(x9), data = dane_low)
model_high <-lm(y ~ x1 + x2 + log(x9), data = dane_high)

RSS_full <- sum(residuals(model_logx)^2)
RSS_low <- sum(residuals(model_low)^2)
RSS_high <- sum(residuals(model_high)^2)

F_statistic <- ((RSS_full - (RSS_low + RSS_high)) / (RSS_low + RSS_high)) *((43-2*(4+1))/(4+1))
F_statistic

p_value <- 1 - pf(F_statistic, 4, 43-8)
p_value

# Testowanie stabilności postaci analitycznej modelu (test Ramsey’a RESET, test liczby serii).
# Test RESET
resettest(model_logx)

# Test serii
res <- resid(model_logx)
dane_ucz$reszty <- res
posortowane <- dane_ucz[order(dane_ucz$x1), ]
znaki <- ifelse(posortowane$reszty > 0, "+", "-")
n1 <- sum(znaki == "+")
n2 <- sum(znaki == "-")
liczba_serii <- 1 + sum(znaki[-1] != znaki[-length(znaki)])
E_R   <- 2 * n1 * n2 / (n1 + n2) + 1
Var_R <- (2 * n1 * n2 * (2 * n1 * n2 - n1 - n2)) / ((n1 + n2)^2 * (n1 + n2 - 1))
Z <- (liczba_serii - E_R) / sqrt(Var_R)
p_value <- 2 * pnorm(-abs(Z))

# Badanie efektu katalizy
dane_ucz$log_x9 <- log(dane_ucz$x9)
dane_ucz
zmienne_model <- dane_ucz[, c("y", "x1", "x2", "log_x9")]
zmienne_model
korelacje_model <- cor(zmienne_model, use="complete.obs", method = "pearson")
corr_mat <- korelacje_model
corr_mat
new_vars <- c("x1p", "x2p", "log_x9")
R0 <- c(
  x1p    = -corr_mat["y", "x1"],                         
  x2p    = -corr_mat["y", "x2"],
  log_x9 =  corr_mat["y", "log_x9"]
)
R0
R <- matrix(NA, nrow = 3, ncol = 3,
            dimnames = list(new_vars, new_vars))

for(i in new_vars) {
  for(j in new_vars) {
    orig_i <- if(i == "x1p") "x1" else if(i == "x2p") "x2" else "log_x9"
    orig_j <- if(j == "x1p") "x1" else if(j == "x2p") "x2" else "log_x9"
    sign_i <- if(i %in% c("x1p","x2p")) -1 else 1
    sign_j <- if(j %in% c("x1p","x2p")) -1 else 1
    R[i,j] <- sign_i * sign_j * corr_mat[orig_i, orig_j]
  }
}

install.packages("mbstats")
remotes::install_github("mbojan/mbstats")
remotes::install_github("mbojan/mbstats")

x <- zmienne_model[, c("x1", "x2", "log_x9")]
y <- zmienne_model$y

wyniki_hellwig <- hellwig(y, x, method = "pearson")
print(wyniki_hellwig)

R_df  <- as.data.frame(R)
R0_df <- data.frame(variable = names(R0), correlation = as.numeric(R0))

R0_df
R_df

kombinacje_hellwig <- wyniki_hellwig
kombinacje_hellwig$varlist <- sapply(kombinacje_hellwig$k, function(k) {
  index_to_name <- c("x1p", "x2p", "log_x9")
  indeksy <- unlist(strsplit(k, "-"))
  nazwy <- index_to_name[as.numeric(indeksy)]
  paste(sort(nazwy), collapse = "-")
})
var_to_index <- c(x1p = 1, x2p = 2, log_x9 = 3)

hellwig_H_map <- setNames(wyniki_hellwig$h, sapply(wyniki_hellwig$k, function(k) {
  indeksy <- unlist(strsplit(k, "-"))
  zmienne <- names(var_to_index)[as.numeric(indeksy)]
  paste(sort(zmienne), collapse = "-")
}))
calc_kataliza <- function(var1, var2, R_df, R0_df, H_map) {
  pair_key <- paste(sort(c(var1, var2)), collapse = "-")
  
  r_i  <- R0_df$correlation[R0_df$variable == var1]
  r_j  <- R0_df$correlation[R0_df$variable == var2]
  r_ij <- R_df[var1, var2]
  
  H <- H_map[[pair_key]]
  
  R2 <- 0.9061
  eta <- R2 - H
  W_eta <- eta / R2 * 100
  
  data.frame(
    Xi       = var1,
    Xj       = var2,
    r_i      = r_i,
    r_j      = r_j,
    r_ij     = r_ij,
    H        = H,
    R2       = R2,
    eta      = eta,
    W_eta_pc = W_eta,
    stringsAsFactors = FALSE
  )
}
pairs <- list(
  c("x1p", "x2p"),
  c("x1p", "log_x9"),
  c("x2p", "log_x9")
)

results <- bind_rows(lapply(pairs, function(p) {
  calc_kataliza(p[1], p[2], R_df, R0_df, hellwig_H_map)
}))

results <- results %>%
  mutate(across(r_i:W_eta_pc, ~round(., 4)))
print(results)

# 6. Prezentacja ostatecznej postaci modelu i jego ocena.
# Ocena istotności zmiennych (test t-Studenta i test Walda).
model_ostateczny <- lm(y ~ x2 + log(x9), data = dane_ucz)
summary(model_ostateczny)

# Test Walda
vcov(model_ostateczny)
wald.test(vcov(model_ostateczny),
          b    = coef(model_ostateczny),
          Terms = c(2, 3))

wald.test(vcov(model_ostateczny),
          b    = coef(model_ostateczny),
          Terms = 2)

wald.test(vcov(model_ostateczny),
          b    = coef(model_ostateczny),
          Terms = 3)

# 7. Wyznaczenie prognozy punktowej. Obliczenie względnego błędu prognozy EX POST.
dane_test <- subset(dane_test, select = -c(x1))
nowe_dane <- data.frame(
  x2 = c(-64.8000000, -67.8333330, -55.1666670,  15.3666670,   -9.5333330,    6.3000000),
  x9 = c( 5283.0000,   4101.8000, 18257.2000,  1090.8250,   3219.7000, 20467.2000)
)
y_rzeczywiste <- c(30.94667,   26.83000,  251.98333, -227.12000,  -22.51333,  271.29667)

y_hat <- predict(model_ostateczny, newdata = nowe_dane)

blad_wzgledny <- abs(y_rzeczywiste - y_hat) / abs(y_rzeczywiste) * 100

wyniki <- data.frame(
  y_rzeczywiste = y_rzeczywiste,
  y_hat         = y_hat,
  blad_wzgledny = blad_wzgledny
)

print(wyniki)